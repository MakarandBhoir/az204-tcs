﻿using StackExchange.Redis;

string connectionString = "tcsrediscache.redis.cache.windows.net:6380,password=tw0oMuOs3IhimBna072E5UDznEQR0H0o1AzCaM0iPro=,ssl=True,abortConnect=False";

ConnectionMultiplexer redis = ConnectionMultiplexer.Connect(connectionString);

SetCacheData();
GetCacheData();

void SetCacheData()
{
    IDatabase database=redis.GetDatabase();

    database.StringSet("top-3-courses", "AZ-204,AZ-104,AZ-400");

    Console.WriteLine("Cache data set");
}

void GetCacheData()
{
    IDatabase database = redis.GetDatabase();
    if (database.KeyExists("top-3-courses"))
        Console.WriteLine(database.StringGet("top-3-courses"));
    else
        Console.WriteLine("key does not exist");

}