﻿
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;

string connectionString = "DefaultEndpointsProtocol=https;AccountName=storageacc104523;AccountKey=V1BifpTcX6zcucKjK4ncvIjDHgY5LVrs4GhNz9qjp0gjUthhuLPdCG1nnH8eV7I0uMoE1gEMJt3t+ASt4af/LQ==;EndpointSuffix=core.windows.net";
string containerName = "container1";
string blobName = "devloper-associate";
string filePath = "D:\\Training\\TCS\\DEPR\\Azure Developer\\Badge Images\\microsoft-certified-azure-developer-associate.1-copy.png";


BlobClient blobClient=new BlobClient(connectionString, containerName, blobName);

await blobClient.DownloadToAsync(filePath);

Console.WriteLine("The blob is downloaded");



