SELECT * FROM Orders 

SELECT * FROM Orders o WHERE o.category="Laptop"

SELECT o.orderId,o.category,o.quantity FROM Orders o WHERE o.category="Laptop"

SELECT SUM(o.quantity) AS Quantity,o.category 
FROM Orders o
GROUP BY o.category


SELECT o.orderId,o.category,o.quantity,o.customer FROM Orders o WHERE o.category="Laptop"
SELECT o.orderId,o.category,o.quantity,o.customer.customerName FROM Orders o WHERE o.category="Laptop"

SELECT c.orders FROM Customer c

SELECT o.quantity
FROM o in Customer.orders

SELECT SUM(o.quantity) AS Quantity,c.customerName 
FROM Customer c
JOIN o in c.orders
GROUP BY c.customerName