﻿using Azure.Storage.Queues;

string connectionString = "DefaultEndpointsProtocol=https;AccountName=storageacc65243;AccountKey=kqunJ/YopP4W6CyY3GaIO25a3OI/1o6oeHDNZrFyywwQSlgAGXukjz7gF1NTqznPSclgyni7fHz0+AStL6/lhQ==;EndpointSuffix=core.windows.net";
string queueName = "message-queue";

sendMessage("Message 1");
sendMessage("Message 2");

void sendMessage(string message)
{
    QueueClient queueClient = new QueueClient(connectionString, queueName);
    if (queueClient.Exists())
    {
       queueClient.SendMessage(message);
        Console.WriteLine("Message sent {0}", message);
    }
}
