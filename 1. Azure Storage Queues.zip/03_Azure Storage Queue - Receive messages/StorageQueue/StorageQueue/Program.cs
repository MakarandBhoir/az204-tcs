﻿
using Azure.Storage.Queues;
using Azure.Storage.Queues.Models;

string connectionString = "DefaultEndpointsProtocol=https;AccountName=storageacc65243;AccountKey=kqunJ/YopP4W6CyY3GaIO25a3OI/1o6oeHDNZrFyywwQSlgAGXukjz7gF1NTqznPSclgyni7fHz0+AStL6/lhQ==;EndpointSuffix=core.windows.net";
string queueName = "storage-queue";

//SendMessage("Test Message 1");
//SendMessage("Test Message 2");
//PeekMessage();
ReceiveMessage();


void SendMessage(string message)
{
    QueueClient queueClient = new QueueClient(connectionString,queueName);

    if(queueClient.Exists())
    {
        queueClient.SendMessage(message);
        Console.WriteLine("The message has been sent");
    }
}

void PeekMessage()
{
    QueueClient queueClient = new QueueClient(connectionString, queueName);
    int maxMessages = 10;

    PeekedMessage[] peekMessages=queueClient.PeekMessages(maxMessages);
    Console.WriteLine("The messages in the queue are");
    foreach(var peekMessage in peekMessages)
    {
        Console.WriteLine(peekMessage.Body);
    }
}

void ReceiveMessage()
{
    QueueClient queueClient = new QueueClient(connectionString, queueName);
    int maxMessages = 10;

    QueueMessage[] queueMessages = queueClient.ReceiveMessages(maxMessages);
    Console.WriteLine("The messages in the queue are");
    foreach (var message in queueMessages)
    {
        Console.WriteLine(message.Body);
        queueClient.DeleteMessage(message.MessageId, message.PopReceipt);
    }
}


