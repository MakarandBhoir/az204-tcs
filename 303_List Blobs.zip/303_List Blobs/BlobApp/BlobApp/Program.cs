﻿
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;

string connectionString = "DefaultEndpointsProtocol=https;AccountName=storageacc104523;AccountKey=V1BifpTcX6zcucKjK4ncvIjDHgY5LVrs4GhNz9qjp0gjUthhuLPdCG1nnH8eV7I0uMoE1gEMJt3t+ASt4af/LQ==;EndpointSuffix=core.windows.net";
string containerName = "container1";

BlobContainerClient blobContainerClient = new BlobContainerClient(connectionString,containerName);

await foreach(BlobItem blobItem in blobContainerClient.GetBlobsAsync())
{
    Console.WriteLine("The Blob Name is {0}",blobItem.Name);
    Console.WriteLine("The Blob Size is {0}", blobItem.Properties.ContentLength);
}


