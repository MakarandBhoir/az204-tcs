﻿using Azure.Storage.Blobs;

string connectionString = "DefaultEndpointsProtocol=https;AccountName=tcsstorageacc;AccountKey=o4VSTrDO8NNGfWOIjMy6Y9UCWY1GrME/v0AWstYXHKePyHpvr0EvCBAEW+hm8SNnP2MdUAJtsiuM+ASt3vWXug==;EndpointSuffix=core.windows.net";
string containerName = "data1";

BlobServiceClient blobServiceClient = new BlobServiceClient(connectionString);

Console.WriteLine("Creating the container");

await blobServiceClient.CreateBlobContainerAsync(containerName);

/*
If you want to specify properties for the container

await blobServiceClient.CreateBlobContainerAsync(containerName,Azure.Storage.Blobs.Models.PublicAccessType.Blob);
*/
Console.WriteLine("Container creation complete");